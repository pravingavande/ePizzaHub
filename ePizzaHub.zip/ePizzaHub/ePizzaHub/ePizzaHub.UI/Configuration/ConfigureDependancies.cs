﻿using ePizzaHub.Services.Implementation;
using ePizzaHub.Services.Interface;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ePizzaHub.UI.Configuration
{
    public static class ConfigureDependancies
    {
        public static void AddServices(IServiceCollection services)
        {
           
            services.AddScoped<IAuthenticationService, AuthenticationService>();
            services.AddScoped<ICatalogService, CatalogServices>();

        }

    }
}
