﻿using ePizzaHub.Entites;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ePizzaHub.Services.Interface
{
   public interface IAuthenticationService
    {
        bool CreateUser(User user, string Password);

        Task<bool> SignOut();

        User AuthenticateUser(string username, string password);
        User GetUser(string username);

        
    }
}
