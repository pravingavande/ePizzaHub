﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
using Microsoft.AspNetCore.Identity;

namespace ePizzaHub.Entites
{
   public class User :IdentityUser<int>
    {
        public  string Name { get; set; }

        
        [NotMapped]
        public string[] Role { get; set; }


    }
}
